G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,9.0.1*
G04 #@! TF.CreationDate,2025-11-02T15:23:51+01:00*
G04 #@! TF.ProjectId,VORTAC_TOOL,564f5254-4143-45f5-944f-4f4c2e6b6963,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.1) date 2025-11-02 15:23:51*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10RoundRect,0.112500X-0.187500X-0.112500X0.187500X-0.112500X0.187500X0.112500X-0.187500X0.112500X0*%
%ADD11RoundRect,0.250000X-0.300000X-0.300000X0.300000X-0.300000X0.300000X0.300000X-0.300000X0.300000X0*%
%ADD12RoundRect,0.291667X-0.758333X-0.758333X0.758333X-0.758333X0.758333X0.758333X-0.758333X0.758333X0*%
%ADD13C,2.100000*%
%ADD14C,2.600000*%
%ADD15C,1.700000*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,D3*
X105790000Y-49730000D03*
X107890000Y-49730000D03*
G04 #@! TD*
D11*
G04 #@! TO.C,D6*
X94400000Y-49730000D03*
X97200000Y-49730000D03*
G04 #@! TD*
D10*
G04 #@! TO.C,D4*
X102060000Y-49730000D03*
X104160000Y-49730000D03*
G04 #@! TD*
D12*
G04 #@! TO.C,J2*
X98910000Y-54460000D03*
D13*
X96310000Y-54460000D03*
G04 #@! TD*
D14*
G04 #@! TO.C,J1*
X93400000Y-52000000D03*
X97200000Y-52000000D03*
X101000000Y-52000000D03*
X104800000Y-52000000D03*
X108600000Y-52000000D03*
G04 #@! TD*
D15*
G04 #@! TO.C,J3*
X103690000Y-54620000D03*
X105690000Y-54620000D03*
X107690000Y-54620000D03*
G04 #@! TD*
M02*

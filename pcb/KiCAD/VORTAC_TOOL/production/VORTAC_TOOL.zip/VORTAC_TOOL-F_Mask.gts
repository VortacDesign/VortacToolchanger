G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,9.0.1*
G04 #@! TF.CreationDate,2025-10-29T21:29:14+01:00*
G04 #@! TF.ProjectId,VORTAC_TOOL,564f5254-4143-45f5-944f-4f4c2e6b6963,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.1) date 2025-10-29 21:29:14*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10RoundRect,0.270000X0.630000X-1.030000X0.630000X1.030000X-0.630000X1.030000X-0.630000X-1.030000X0*%
%ADD11O,1.800000X2.600000*%
%ADD12C,2.600000*%
%ADD13C,1.700000*%
%ADD14RoundRect,0.112500X-0.187500X-0.112500X0.187500X-0.112500X0.187500X0.112500X-0.187500X0.112500X0*%
%ADD15RoundRect,0.250000X-0.300000X-0.300000X0.300000X-0.300000X0.300000X0.300000X-0.300000X0.300000X0*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,J2*
X95350000Y-54500000D03*
D11*
X99150000Y-54500000D03*
G04 #@! TD*
D12*
G04 #@! TO.C,J1*
X93400000Y-52000000D03*
X97200000Y-52000000D03*
X101000000Y-52000000D03*
X104800000Y-52000000D03*
X108600000Y-52000000D03*
G04 #@! TD*
D13*
G04 #@! TO.C,J3*
X102550000Y-54750000D03*
X104750000Y-54750000D03*
X106950000Y-54750000D03*
G04 #@! TD*
D14*
G04 #@! TO.C,D2*
X102200000Y-49750000D03*
X104300000Y-49750000D03*
G04 #@! TD*
D15*
G04 #@! TO.C,D3*
X94350000Y-49500000D03*
X97150000Y-49500000D03*
G04 #@! TD*
D14*
G04 #@! TO.C,D1*
X106200000Y-49750000D03*
X108300000Y-49750000D03*
G04 #@! TD*
M02*
